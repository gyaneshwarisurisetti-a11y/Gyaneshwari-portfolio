const $ = (s, c=document) => c.querySelector(s);
const $$ = (s, c=document) => [...c.querySelectorAll(s)];
$("#year").textContent = new Date().getFullYear();

const io = new IntersectionObserver((entries)=>{
  entries.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add("visible"); io.unobserve(e.target); }});
},{threshold:.12});
$$(".reveal").forEach(el=>io.observe(el));

const glow = $(".cursor-glow");
window.addEventListener("pointermove", e=>{
  if(glow){ glow.style.left=e.clientX+"px"; glow.style.top=e.clientY+"px"; }
});

const stage = $(".portrait-stage"), card = $("#portraitCard");
if(stage && card && !matchMedia("(prefers-reduced-motion: reduce)").matches){
  stage.addEventListener("pointermove", e=>{
    const r=stage.getBoundingClientRect();
    const x=(e.clientX-r.left)/r.width-.5, y=(e.clientY-r.top)/r.height-.5;
    card.style.transform=`rotateY(${x*11}deg) rotateX(${-y*9}deg) translateZ(10px)`;
    const shine=$(".portrait-shine",card);
    shine.style.transform=`translateX(${x*45-15}%) rotate(5deg)`;
  });
  stage.addEventListener("pointerleave",()=>{ card.style.transform="rotateY(0) rotateX(0)"; });
}

$$(".magnetic").forEach(btn=>{
  btn.addEventListener("pointermove",e=>{
    const r=btn.getBoundingClientRect(), x=e.clientX-r.left-r.width/2, y=e.clientY-r.top-r.height/2;
    btn.style.transform=`translate(${x*.08}px,${y*.08}px)`;
  });
  btn.addEventListener("pointerleave",()=>btn.style.transform="");
});

window.addEventListener("scroll",()=>{
  const y=scrollY;
  const p=$(".portrait-card");
  if(p && innerWidth>850 && y<innerHeight*1.2) p.style.translate=`0 ${y*.08}px`;
},{passive:true});