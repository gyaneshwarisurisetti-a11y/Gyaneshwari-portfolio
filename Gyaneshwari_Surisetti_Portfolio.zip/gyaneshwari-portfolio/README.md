# Gyaneshwari Surisetti — Portfolio

A cinematic, responsive portfolio built as a dependency-free static website.

## Run locally
Open `index.html` directly, or use VS Code + Live Server.

## Deploy
Upload this folder to Netlify, Cloudflare Pages, GitHub Pages, or any static host.

## Files
- `index.html` — page structure and real CV content
- `styles.css` — responsive design, glass effects, animations, portrait treatment
- `script.js` — reveal effects, cursor glow, magnetic buttons, interactive 3D portrait tilt
- `assets/gyaneshwari.jpg` — portrait
- `assets/Gyaneshwari_Surisetti_CV.pdf` — downloadable CV

## Before publishing
Add Gyaneshwari's exact LinkedIn URL if desired. The current site intentionally does not invent one.
