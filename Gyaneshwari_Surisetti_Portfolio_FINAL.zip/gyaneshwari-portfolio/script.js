const qs=(s)=>document.querySelector(s), qsa=(s)=>document.querySelectorAll(s);
qs('#year').textContent=new Date().getFullYear();
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');io.unobserve(e.target)}}),{threshold:.12});qsa('.reveal').forEach(el=>io.observe(el));
window.addEventListener('scroll',()=>{const h=document.documentElement;qs('#progress').style.width=((h.scrollTop/(h.scrollHeight-h.clientHeight))*100)+'%'});
const glow=qs('.cursor-glow');window.addEventListener('pointermove',e=>{glow.style.left=e.clientX+'px';glow.style.top=e.clientY+'px'});
const card=qs('#portraitCard');if(card){card.addEventListener('pointermove',e=>{const r=card.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;card.style.transform=`rotateY(${x*9}deg) rotateX(${-y*7}deg) translateZ(6px)`});card.addEventListener('pointerleave',()=>card.style.transform='rotateY(0) rotateX(0)')}
qsa('.magnetic').forEach(b=>{b.addEventListener('pointermove',e=>{const r=b.getBoundingClientRect();b.style.transform=`translate(${(e.clientX-r.left-r.width/2)*.08}px,${(e.clientY-r.top-r.height/2)*.08}px)`});b.addEventListener('pointerleave',()=>b.style.transform='')});
